/*import React from 'react';
import Slider from 'react-slick';

const BackgroundSlideshow = () => {
  const images = [
    '/pu1.jpg',
    '/pu2.jpg',
    '/pu3.jpg',
  ];

  const settings = {
    infinite: true,
    autoplay: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
    arrows: false,
    dots: false,
  };

  return (
    <div className="background-slideshow">
      <Slider {...settings}>
        {images.map((image, index) => (
          <div key={index}>
            <img src={image} alt={`Slide ${index}`} className="background-slide" />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default BackgroundSlideshow;*/


/*import React from 'react';
import Slider from 'react-slick';

const BackgroundSlideshow = () => {
  const images = [
    '../images/pu1.jpg',
    '../images/pu2.jpg',
    '../images/pu3.jpg',
  ];

  const settings = {
    infinite: true,
    autoplay: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
    arrows: false,
    dots: false,
  };

  return (
    <div className="background-slideshow">
      <Slider {...settings}>
        {images.map((image, index) => (
          <div key={index}>
            <img src={image} alt={`Slide ${index}`} className="background-slide" />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default BackgroundSlideshow;

*/
// BackgroundSlideshow.js
// BackgroundSlideshow.js
// BackgroundSlideshow.js
import React, { useState, useEffect } from 'react';
import pu1 from '../images/pu1.jpg';  // Import images
import pu2 from '../images/pu2.jpg';
import pu3 from '../images/pu3.jpg';
import './BackgroundSlideshow.css';

function BackgroundSlideshow() {
  const [background, setBackground] = useState(pu1); // Set the initial background image

  useEffect(() => {
    const interval = setInterval(() => {
      setBackground((prevBackground) => {
        if (prevBackground === pu1) return pu2;
        if (prevBackground === pu2) return pu3;
        return pu1;
      });
    }, 6000); // Change the background every 6 seconds

    return () => clearInterval(interval); // Clean up on unmount
  }, []);

  return (
    <div
      className="background-slideshow"
      style={{
        backgroundImage: `url(${background})`, // Dynamically change background image
      }}
    >
      {/* Additional content can go here */}
    </div>
  );
}

export default BackgroundSlideshow;

