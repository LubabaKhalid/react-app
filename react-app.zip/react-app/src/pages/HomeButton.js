// src/components/HomeButton.js
import React from 'react';
import './HomeButton.css';

const HomeButton = () => {
  const scrollToHome = () => {
    const homeSection = document.getElementById('home');
    if (homeSection) {
      homeSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = '/'; // Fallback if not on single page
    }
  };

  return (
    <button className="home-button" onClick={scrollToHome}>
      ⬆
    </button>
  );
};

export default HomeButton;
