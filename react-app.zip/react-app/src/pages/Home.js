/*import './Home.css';
import '../App.css'
import React from 'react';
import BackgroundSlideshow from '../components/BackgroundSlideshow';

function Home() {
  return (
    <div className="home-container">
      <BackgroundSlideshow />
      <div className="content">
        <h1>Students Registration</h1>
        <p></p>
      </div>
    </div>
  );
}

export default Home;*/


// Home.js
import React from 'react';
import '../App.css';
import BackgroundSlideshow from '../components/BackgroundSlideshow'; // Make sure this is set up correctly
import './Home.css';

function Home() {
  return (
    <div className="home-container">
      <BackgroundSlideshow /> {/* Slideshow is positioned in the background */}
      {/* Optional: adds an overlay effect */}
      <div className="content">
        <h1>Welcome to Student Registration Portal</h1>
        <p>Register, Learn and Connect</p>
      </div>
    </div>
  );
}

export default Home;

